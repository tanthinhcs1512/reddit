import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-header',
  templateUrl: './_header.component.html',
})
export class HeaderComponent {}
